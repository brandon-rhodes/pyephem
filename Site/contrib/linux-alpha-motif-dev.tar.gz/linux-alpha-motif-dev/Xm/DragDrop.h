/* 
 * (c) Copyright 1989, 1990, 1991, 1992 OPEN SOFTWARE FOUNDATION, INC. 
 * ALL RIGHTS RESERVED 
*/ 
/* 
 * Motif Release 1.2
*/ 
/*   DragDrop.h,v 1.1.1.1 1995/07/24 22:06:38 */
/*
*  (c) Copyright 1990, 1991, 1992 HEWLETT-PACKARD COMPANY */
#ifndef _XmDragDrop_h
#define _XmDragDrop_h

#include <Xm/DragC.h>
#include <Xm/DragIcon.h>
#include <Xm/DropTrans.h>
#include <Xm/DragOverS.h>
#include <Xm/DropSMgr.h>

#endif /* _XmDragDrop_h */
